Place your Modernizr Javascript file in this directory.

It can be compressed or uncompressed (although of the course the former is better).

Regardless, the file in this folder MUST be named modernizr.js.